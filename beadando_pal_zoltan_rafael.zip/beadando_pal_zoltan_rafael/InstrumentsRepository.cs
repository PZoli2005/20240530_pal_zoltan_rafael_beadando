﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace beadando_pal_zoltan_rafael
{
    internal class InstrumentsRepository
    {
        private HangszerContext HangszerContext;
        public InstrumentsRepository(HangszerContext context)
        {
            this.HangszerContext = context;
        }
        public List<Instruments> GetInstruments()
        {
            return HangszerContext.Instruments.ToList();
        }
        public Instruments GetInstrumentsById(int id)
        {
            return HangszerContext.Instruments.Find(id);
        }
        public void InsertPerson(Instruments student)
        {
            HangszerContext.Instruments.Add(student);
        }
        public void DeleteInstrument(int studentID)
        {
            Instruments instrument = HangszerContext.Instruments.Find(studentID);
            HangszerContext.Instruments.Remove(instrument);
        }
        public void UpdateStudent(Instruments student)
        {
            HangszerContext.Instruments.Find(student.id).Tipus = student.Tipus;
            HangszerContext.Instruments.Find(student.id).GyartasiEv = student.GyartasiEv;
            HangszerContext.Instruments.Find(student.id).Marka = student.Marka;

        }
        public void Save()
        {
            HangszerContext.SaveChanges();
        }
        public void Disopse()
        {
            HangszerContext.Dispose();
            GC.SuppressFinalize(this);

        }
    }
}
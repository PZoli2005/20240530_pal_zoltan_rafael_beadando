﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace beadando_pal_zoltan_rafael
{
    [Table("hangszerek")]
    class Instruments
    {
        [Key]
        [Column("Id")]
        public int id { get; set; }

        [Column("Tipus")]
        public string Tipus { get; set; }

        [Column("GyartasiEv")]
        public string GyartasiEv { get; set; }

        [Column("Marka")]
        public string Marka { get; set; }
    }
}
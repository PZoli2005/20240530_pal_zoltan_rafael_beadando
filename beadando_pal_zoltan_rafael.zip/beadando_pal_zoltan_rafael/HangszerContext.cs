﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace beadando_pal_zoltan_rafael
{
    internal class HangszerContext : Microsoft.EntityFrameworkCore.DbContext
    {
        private string connectionstring = ConfigurationManager.AppSettings.Get("DBurl");
        public HangszerContext()
        {
            connectionstring = connectionstring;
        }

        public System.Data.Entity.DbSet<Instruments> Instruments { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySQL(connectionstring);
        }

    }
}
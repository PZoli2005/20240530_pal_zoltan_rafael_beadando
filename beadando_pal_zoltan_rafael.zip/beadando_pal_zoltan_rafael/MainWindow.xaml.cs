﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace beadando_pal_zoltan_rafael
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CheckDatabaseConnection();
        }
        private void CheckDatabaseConnection()
        {
            try
            {
                HangszerContext dbcontext = new HangszerContext();
                if (!dbcontext.Database.CanConnect())
                {
                    MessageBox.Show("Database Connect Failed!");
                    System.Environment.Exit(1);
                }
                dbcontext.Dispose();
            }

            catch (Exception ex)
            {
                MessageBox.Show("Database Connect Failed With An Exception!");
                throw;
            }
        }
        private void Exit_button_Click(object sender, RoutedEventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void Utos_Click(object sender, RoutedEventArgs e)
        {
            MainWindow UtosWindow = new MainWindow();
            UtosWindow.Show();
        }

        private void Huros_Click(object sender, RoutedEventArgs e)
        {
            MainWindow HurosWindow = new MainWindow();
            HurosWindow.Show();
        }

        private void Fuvos_Click(object sender, RoutedEventArgs e)
        {
            MainWindow FuvosWindow = new MainWindow();
            FuvosWindow.Show();
        }

    }
}
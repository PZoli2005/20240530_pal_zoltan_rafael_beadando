﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace beadando_pal_zoltan_rafael
{
    /// <summary>
    /// Interaction logic for UtosWindow.xaml
    /// </summary>
    partial class UtosWindow : Window
    {

        private InstrumentsRepository InstrumentsRepository = null;
        private List<Instruments> selectInstruments;
        private Op operation = Op.No;
        enum Op
        {
            Add,
            Upd,
            No,
        }
        public UtosWindow()
        {
            InitializeComponent();
            InstrumentsRepository = new InstrumentsRepository(new HangszerContext());
            LoadStudentsGrid();
            textBoxTipus.IsEnabled = false;
            textBoxGyartasiEv.IsEnabled = false;
            textBoxMarka.IsEnabled = false;
        }
        private void LoadStudentsGrid()
        {
            Cursor = Cursors.Wait;
            selectInstruments = InstrumentsRepository.GetInstruments();
            InstrumentsDataGrid.ItemsSource = selectInstruments;
            Cursor = Cursors.Wait;
        }
        private void btn_New_Click(object sender, EventArgs e)
        {
            textBoxTipus.IsEnabled = true;
            textBoxGyartasiEv.IsEnabled = true;
            textBoxMarka.IsEnabled = true;
            textBoxTipus.Text = "";
            textBoxGyartasiEv.Text = "";
            textBoxMarka.Text = "";

        }
        private void btnSave_Click(object sender, RoutedEvent e)
        {
            if (operation == Op.Add && textBoxTipus.Text != "" && textBoxGyartasiEv.Text != "" && textBoxMarka.Text != "")
            {
                InstrumentsRepository.InsertPerson(new Instruments
                {
                    Tipus = textBoxTipus.Text,
                    GyartasiEv = textBoxGyartasiEv.Text,
                    Marka = textBoxMarka.Text,
                });
                InstrumentsRepository.Save();
                LoadStudentsGrid();

                textBoxTipus.IsEnabled = false;
                textBoxGyartasiEv.IsEnabled = false;
                textBoxMarka.IsEnabled = false;
                textBoxTipus.Text = "";
                textBoxGyartasiEv.Text = "";
                textBoxMarka.Text = "";
                operation = Op.No;
                textBoxTipus.Focus();
            }
            else
            {
                MessageBox.Show("Operation is not INSERT or the required fields are empty. ");
            }

        }
        private void dataGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            textBoxTipus.Text = selectInstruments[InstrumentsDataGrid.SelectedIndex].Tipus;
            textBoxGyartasiEv.Text = selectInstruments[InstrumentsDataGrid.SelectedIndex].GyartasiEv;
            textBoxMarka.Text = selectInstruments[InstrumentsDataGrid.SelectedIndex].Marka;
            textBoxTipus.IsEnabled = false;
            textBoxGyartasiEv.IsEnabled = false;
            textBoxMarka.IsEnabled = false;
            operation = Op.Upd;

        }
        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (operation == Op.Upd)
            {
                Instruments instrument_update = InstrumentsRepository.GetInstrumentsById(selectInstruments[InstrumentsDataGrid.SelectedIndex].id);
                InstrumentsRepository.GetInstrumentsById(selectInstruments[InstrumentsDataGrid.SelectedIndex].id);
                instrument_update.Tipus = textBoxTipus.Text;
                instrument_update.GyartasiEv = textBoxGyartasiEv.Text;
                instrument_update.Marka = textBoxMarka.Text;
                InstrumentsRepository.UpdateStudent(instrument_update);
                InstrumentsRepository.Save();
                LoadStudentsGrid();
                textBoxTipus.Text = "";
                textBoxGyartasiEv.Text = "";
                textBoxMarka.Text = "";
                textBoxTipus.IsEnabled = false;
                textBoxGyartasiEv.IsEnabled = false;
                textBoxMarka.IsEnabled = false;
                operation = Op.No;

            }
            else
            {
                MessageBox.Show("The Operation Is Not UPDATE");
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }
    }
}